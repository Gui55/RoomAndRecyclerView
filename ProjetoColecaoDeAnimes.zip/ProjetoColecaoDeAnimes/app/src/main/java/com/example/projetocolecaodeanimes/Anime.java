package com.example.projetocolecaodeanimes;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Anime {

    public Anime(String nome, String genero, int ano){
        this.nome = nome;
        this.ano = ano;
        this.genero = genero;
    }

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String nome;
    public int ano;
    public String genero;

}
