package com.example.projetocolecaodeanimes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText enterNome, enterAno, enterGenero;
    Button botaoCadastro, scrollButton, botaoLimpar;
    public static AnimeDAO anDAO;
    TextView test;
    private int c = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        test = findViewById(R.id.testText);

        //
        AnimeDatabase adb = Room.databaseBuilder(getApplicationContext(), AnimeDatabase.class,
                "animedb").allowMainThreadQueries().build(); //allowMainThreads é só pra testes

        anDAO = adb.anDao();


        enterNome=findViewById(R.id.nomeInput);
        enterAno=findViewById(R.id.anoInput);
        enterGenero=findViewById(R.id.generoInput);

        botaoCadastro=findViewById(R.id.botaoCadastro);

        botaoCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if((!enterNome.getText().toString().equals("")) &&
                        (!enterAno.getText().toString().equals("")) &&
                        (!enterGenero.getText().toString().equals(""))){

                    anDAO.insert(new Anime(
                            enterNome.getText().toString(),
                            enterGenero.getText().toString(),
                            Integer.parseInt(enterAno.getText().toString()
                            )));

                    Toast.makeText(MainActivity.this, enterNome.getText().toString()+" cadastrado com sucesso!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity.this, "Inválido", Toast.LENGTH_SHORT).show();
                }


            }
        });

        scrollButton=findViewById(R.id.scrollButton);

        scrollButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), RecycleActivity.class);
                startActivity(intent);

                //Toast.makeText(MainActivity.this,anDAO.getAnimes().size(),Toast.LENGTH_SHORT).show();

            }
        });

        botaoLimpar=(Button)findViewById(R.id.buttonLimpar);

        botaoLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                anDAO.apagarTudo();

            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        c = 0;
    }
}
